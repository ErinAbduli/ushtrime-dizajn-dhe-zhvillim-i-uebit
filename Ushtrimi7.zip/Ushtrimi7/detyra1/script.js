let p = document.getElementById("p1");
p.textContent = "Përshendetje, studentë!";

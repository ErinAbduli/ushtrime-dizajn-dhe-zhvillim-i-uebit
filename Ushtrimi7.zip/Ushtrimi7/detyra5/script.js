let paragraphs = document.getElementsByClassName("p");

for (p of paragraphs) p.style.color = "green";

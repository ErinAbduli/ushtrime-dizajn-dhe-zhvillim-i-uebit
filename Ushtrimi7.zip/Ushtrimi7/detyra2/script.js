let btn = document.getElementById("btn");
btn.style.backgroundColor = "red";

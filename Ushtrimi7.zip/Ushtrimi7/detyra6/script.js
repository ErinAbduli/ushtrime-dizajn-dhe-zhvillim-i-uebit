let paragraphs = document.getElementsByClassName("p");
let h2 = document.querySelector("h2");

let sum = paragraphs.length;

h2.textContent = "Numri i paragrafeve eshte: " + sum;

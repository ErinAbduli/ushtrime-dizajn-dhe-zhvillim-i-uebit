let box = document.getElementById("box");
box.style.border = "2px solid black";

let titulli = document.getElementsByTagName("h1");

titulli[0].innerHTML = "Titulli i ri";
